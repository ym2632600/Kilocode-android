package com.kilocode.android.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kilocode.android.data.model.Agent

private const val MAX_CHARS = 4000

@Composable
fun PromptInput(
    onSend: (String) -> Unit,
    isLoading: Boolean,
    agents: List<Agent> = emptyList(),
    selectedAgent: String? = null,
    onAgentSelected: (String?) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var text by remember { mutableStateOf("") }
    var agentMenuExpanded by remember { mutableStateOf(false) }
    val canSend       = text.isNotBlank() && !isLoading
    val showAgentChip = agents.isNotEmpty()
    val charCount     = text.length
    val nearLimit     = charCount > MAX_CHARS * 0.85f

    // Send button scale pulse when canSend flips to true
    val sendScale by animateFloatAsState(
        targetValue   = if (canSend) 1f else 0.88f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label         = "sendScale",
    )

    // Field surface elevation animates when focused (not easily detected without FocusState,
    // so we approximate via text length > 0)
    val fieldElevation by animateDpAsState(
        targetValue   = if (text.isNotEmpty()) 2.dp else 0.dp,
        animationSpec = tween(200),
        label         = "fieldElevation",
    )

    Surface(
        modifier       = modifier.fillMaxWidth(),
        color          = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        Column {
            HorizontalDivider(
                thickness = 0.5.dp,
                color     = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                Row(
                    modifier          = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    // ── Field surface ─────────────────────────────────────────
                    Surface(
                        shape          = RoundedCornerShape(24.dp),
                        color          = MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = fieldElevation,
                        modifier       = Modifier.weight(1f),
                    ) {
                        Row(
                            modifier = Modifier.padding(
                                start  = if (showAgentChip) 6.dp else 14.dp,
                                end    = 10.dp,
                                top    = 9.dp,
                                bottom = 9.dp,
                            ),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            // Agent chip — inline in the field
                            if (showAgentChip) {
                                Box {
                                    Surface(
                                        onClick  = { agentMenuExpanded = true },
                                        shape    = RoundedCornerShape(16.dp),
                                        color    = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                                        modifier = Modifier.height(26.dp),
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(3.dp),
                                        ) {
                                            Icon(
                                                Icons.Rounded.AutoAwesome,
                                                contentDescription = null,
                                                tint     = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(11.dp),
                                            )
                                            Text(
                                                text       = selectedAgent?.take(16) ?: "Agent",
                                                style      = MaterialTheme.typography.labelSmall,
                                                color      = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines   = 1,
                                                fontSize   = 10.sp,
                                            )
                                            Icon(
                                                Icons.Rounded.KeyboardArrowDown,
                                                contentDescription = null,
                                                tint     = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                                modifier = Modifier.size(11.dp),
                                            )
                                        }
                                    }
                                    DropdownMenu(
                                        expanded         = agentMenuExpanded,
                                        onDismissRequest = { agentMenuExpanded = false },
                                    ) {
                                        DropdownMenuItem(
                                            text        = { Text("Default agent") },
                                            onClick     = { onAgentSelected(null); agentMenuExpanded = false },
                                            leadingIcon = { Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(15.dp)) },
                                        )
                                        agents.forEach { agent ->
                                            DropdownMenuItem(
                                                text        = { Text(agent.name) },
                                                onClick     = { onAgentSelected(agent.name); agentMenuExpanded = false },
                                                leadingIcon = { Icon(Icons.Rounded.SmartToy, null, Modifier.size(15.dp)) },
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }

                            // Text field
                            Box(modifier = Modifier.weight(1f)) {
                                BasicTextField(
                                    value           = text,
                                    onValueChange   = { if (it.length <= MAX_CHARS) text = it },
                                    enabled         = !isLoading,
                                    maxLines        = 6,
                                    modifier        = Modifier.fillMaxWidth(),
                                    textStyle       = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurface,
                                    ),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                    keyboardActions = KeyboardActions(onSend = {
                                        if (canSend) { onSend(text.trim()); text = "" }
                                    }),
                                    decorationBox   = { inner ->
                                        if (text.isEmpty()) {
                                            Text(
                                                text  = "Ask Kilo anything…",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                            )
                                        }
                                        inner()
                                    },
                                )
                            }

                            // Character counter — fades in near limit
                            AnimatedVisibility(
                                visible = nearLimit,
                                enter   = fadeIn(tween(150)) + expandHorizontally(),
                                exit    = fadeOut(tween(150)) + shrinkHorizontally(),
                            ) {
                                Text(
                                    text     = "${MAX_CHARS - charCount}",
                                    style    = MaterialTheme.typography.labelSmall,
                                    color    = if (charCount >= MAX_CHARS)
                                                   MaterialTheme.colorScheme.error
                                               else
                                                   MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(start = 6.dp),
                                    fontSize = 10.sp,
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // ── Send / stop button ────────────────────────────────────
                    AnimatedContent(
                        targetState  = isLoading,
                        transitionSpec = {
                            (fadeIn(tween(150)) + scaleIn(tween(150), 0.7f)) togetherWith
                            (fadeOut(tween(100)) + scaleOut(tween(100)))
                        },
                        label = "sendBtn",
                    ) { loading ->
                        if (loading) {
                            // Stop button while loading
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                CircularProgressIndicator(
                                    modifier    = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color       = MaterialTheme.colorScheme.primary,
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .scale(sendScale)
                                    .clip(CircleShape)
                                    .background(
                                        if (canSend) MaterialTheme.colorScheme.primary
                                        else         MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                    ),
                                contentAlignment = Alignment.Center,
                            ) {
                                IconButton(
                                    onClick  = {
                                        if (canSend) {
                                            onSend(text.trim())
                                            text = ""
                                        }
                                    },
                                    enabled  = canSend,
                                    modifier = Modifier.fillMaxSize(),
                                ) {
                                    Icon(
                                        imageVector        = Icons.Rounded.ArrowUpward,
                                        contentDescription = "Send",
                                        tint               = if (canSend) MaterialTheme.colorScheme.onPrimary
                                                             else         MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                        modifier           = Modifier.size(18.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
