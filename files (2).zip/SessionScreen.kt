package com.kilocode.android.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kilocode.android.data.api.ApiClient
import com.kilocode.android.data.repository.SessionRepository
import com.kilocode.android.ui.components.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionScreen(
    sessionId: String,
    serverUrl: String,
    sharedSecret: String?,
    onBack: () -> Unit,
) {
    val apiClient  = remember(serverUrl, sharedSecret) { ApiClient.getInstance(serverUrl, sharedSecret ?: "") }
    val repository = remember(apiClient) { SessionRepository(apiClient) }
    val scope      = rememberCoroutineScope()

    val currentSession by repository.currentSession.collectAsState()
    val messages       by repository.messages.collectAsState()
    val parts          by repository.parts.collectAsState()
    val agents         by repository.agents.collectAsState()
    val isLoading      by repository.isLoading.collectAsState()
    val isConnected    by repository.isConnected.collectAsState()
    val error          by repository.error.collectAsState()

    val listState     = rememberLazyListState()
    var selectedAgent by remember { mutableStateOf<String?>(null) }

    // True when the last item is visible
    val isAtBottom by remember {
        derivedStateOf {
            val info        = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            lastVisible >= (info.totalItemsCount - 1)
        }
    }

    // Top bar fades out slightly when user scrolls down (immersive feel)
    val topBarAlpha by animateFloatAsState(
        targetValue   = if (listState.firstVisibleItemIndex > 0) 0.92f else 1f,
        animationSpec = tween(200),
        label         = "topBarAlpha",
    )

    LaunchedEffect(Unit)   { repository.listAgents() }
    LaunchedEffect(agents) {
        selectedAgent = agents.firstOrNull { it.name == selectedAgent }?.name
            ?: agents.firstOrNull { it.mode == "primary" || it.mode == "all" }?.name
            ?: agents.firstOrNull()?.name
    }
    LaunchedEffect(sessionId) {
        repository.selectSession(sessionId)
        repository.connectSse(sessionId)
    }
    DisposableEffect(sessionId) { onDispose { repository.disconnectSse() } }

    // Scroll to bottom on new messages — only when already at bottom or first load
    val messageCount = messages.size
    LaunchedEffect(messageCount) {
        if (messageCount > 0 && (isAtBottom || messageCount <= 2)) {
            listState.animateScrollToItem(messageCount - 1)
        }
    }
    // Also follow streaming updates to the last message's parts
    val lastPartCount = messages.lastOrNull()?.id?.let { parts[it]?.size } ?: 0
    LaunchedEffect(lastPartCount) {
        if (isAtBottom && messageCount > 0) {
            listState.animateScrollToItem(messageCount - 1)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                modifier = Modifier.graphicsLayer { alpha = topBarAlpha },
                title = {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text       = currentSession?.title ?: "Session",
                            style      = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines   = 1,
                            overflow   = TextOverflow.Ellipsis,
                            modifier   = Modifier.weight(1f, fill = false),
                        )
                        StatusChip(
                            text     = if (isConnected) "Live" else "Offline",
                            isOnline = isConnected,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBack, "Back", modifier = Modifier.size(22.dp))
                    }
                },
                actions = {
                    AnimatedVisibility(
                        visible = isLoading,
                        enter   = fadeIn(tween(150)),
                        exit    = fadeOut(tween(300)),
                    ) {
                        CircularProgressIndicator(
                            modifier    = Modifier.padding(end = 14.dp).size(16.dp),
                            strokeWidth = 2.dp,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        bottomBar = {
            PromptInput(
                onSend          = { text -> scope.launch { repository.sendPrompt(sessionId, text, selectedAgent) } },
                isLoading       = isLoading,
                agents          = agents,
                selectedAgent   = selectedAgent,
                onAgentSelected = { selectedAgent = it },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            // Error banner — slides in from top
            AnimatedVisibility(
                visible = error != null,
                enter   = expandVertically() + fadeIn(),
                exit    = shrinkVertically() + fadeOut(),
            ) {
                error?.let { msg ->
                    ErrorCard(message = msg, onRetry = {
                        scope.launch {
                            repository.clearError()
                            repository.selectSession(sessionId)
                        }
                    })
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier       = Modifier
                        .fillMaxSize()
                        .padding(end = 5.dp),
                    state          = listState,
                    contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
                ) {
                    // Empty state
                    if (messages.isEmpty()) {
                        item {
                            Column(
                                modifier            = Modifier
                                    .fillParentMaxHeight()
                                    .padding(horizontal = 40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                            ) {
                                // Gentle float animation on the icon
                                val float = rememberInfiniteTransition(label = "float")
                                val floatY by float.animateFloat(
                                    initialValue  = 0f,
                                    targetValue   = -8f,
                                    animationSpec = infiniteRepeatable(
                                        tween(1800, easing = FastOutSlowInEasing),
                                        RepeatMode.Reverse,
                                    ),
                                    label = "floatY",
                                )
                                Surface(
                                    shape    = RoundedCornerShape(24.dp),
                                    color    = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                                    modifier = Modifier
                                        .size(64.dp)
                                        .graphicsLayer { translationY = floatY },
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector        = Icons.Rounded.AutoAwesome,
                                            contentDescription = null,
                                            modifier           = Modifier.size(28.dp),
                                            tint               = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text       = "Ask anything",
                                    style      = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Spacer(modifier = Modifier.height(5.dp))
                                Text(
                                    text  = "Kilo will plan, write, and run code.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                )
                            }
                        }
                    }

                    // Messages — each slides in from its side
                    items(
                        items = messages,
                        key   = { it.id ?: it.sessionID ?: messages.indexOf(it).toString() },
                    ) { message ->
                        val msgParts = message.id?.let { parts[it] } ?: emptyList()
                        AnimatedVisibility(
                            visible = true,
                            enter   = if (message.role == "user")
                                fadeIn(tween(180)) + slideInHorizontally(tween(240)) { it / 4 }
                            else
                                fadeIn(tween(180)) + slideInHorizontally(tween(240)) { -it / 4 },
                        ) {
                            MessageBubble(
                                isUser = message.role == "user",
                                parts  = msgParts,
                                agent  = message.agent,
                            )
                        }
                    }

                    // Typing indicator
                    if (isLoading && messages.isNotEmpty()) {
                        item {
                            AnimatedVisibility(
                                visible = true,
                                enter   = fadeIn(tween(200)) + slideInHorizontally(tween(240)) { -it / 4 },
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 18.dp, top = 2.dp, bottom = 4.dp),
                                ) {
                                    // Wrap in a subtle bubble
                                    Surface(
                                        shape = RoundedCornerShape(
                                            topStart = 4.dp, topEnd = 16.dp,
                                            bottomStart = 16.dp, bottomEnd = 16.dp,
                                        ),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                    ) {
                                        TypingIndicator()
                                    }
                                }
                            }
                        }
                    }
                }

                // Scrollbar
                AndroidScrollbar(
                    listState = listState,
                    modifier  = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .padding(vertical = 4.dp)
                        .width(4.dp),
                )

                // Scroll-to-bottom button — spring scale in/out
                AnimatedVisibility(
                    visible  = !isAtBottom && messages.isNotEmpty(),
                    enter    = fadeIn(tween(180)) + scaleIn(
                        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
                        initialScale = 0.6f,
                    ),
                    exit     = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.7f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 14.dp, bottom = 12.dp),
                ) {
                    SmallFloatingActionButton(
                        onClick        = { scope.launch { listState.animateScrollToItem(messages.size - 1) } },
                        shape          = RoundedCornerShape(12.dp),
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor   = MaterialTheme.colorScheme.onSurfaceVariant,
                        elevation      = FloatingActionButtonDefaults.elevation(2.dp, 2.dp),
                    ) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Scroll to latest", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
